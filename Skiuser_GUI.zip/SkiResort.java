package PA06;

import java.io.File;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

public class SkiResort {
	
	SkiCustomer[] customers;
	String fileName;
	int n;
	
	SkiResort(int n){
		customers = new SkiCustomer[n]; //Initiates the customers array
		fileName = "SkiCustomer.txt";
		this.n =n;
	}
	
	// implement the following methods as specified in the assignment
	SkiCustomer addCustomer(/* Provide the required SkiCustomer data in this parameter list*/){return null;}
	void sortCustomer() {}
    void writeToFile() {
    	File file = new File("SkiCustomers.txt");
    	
    	PrintWriter out = new PrintWriter(file);
    	
    	JOptionPane.showMessageDialog(null, "Writing to a file .....");
    	
    	for (int i = 0; i < SkiCustomer.getnoSkiCustomers(); i++)
    		out.println(ski.toString());
    	
    	out.close();
    }
    String display(){
    	String output = "Program Output\n"+ "Name\t" + "Days of Stay";
    	for (SkiCustomer ski:this.customers) {
    		output+= "\n" + ski.toString();
    	
    	//textArea.setText(output);
    }
    return output;return output;}
}
