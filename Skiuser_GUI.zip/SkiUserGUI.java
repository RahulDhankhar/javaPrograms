package PA06;

//add the class template

import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.awt.*;
import javax.swing.*;

class SkiUserGUI extends JFrame implements ActionListener{


	private SkiResort ski;
	
	

// declare UI component objects
	
	//declare labels
	private JLabel lblcustomerName;
	private JLabel lbldaysOfStay;
	private JLabel lblmemberID;
	private JLabel lblnumberOfRentalItems;
	private JLabel lblcoupons;
	private JLabel lblfirstTimeUser;
	
	//declare text field
	private JTextField txtcustomerName;
	private JTextField txtdaysOfStay ;
	private JTextField txtmemberID;
	private JTextField txtnumberOfRentalItems;
	
	//declare button
	private JButton btnCreate;
	private JButton btnSort;
	private JButton btnSave;
	private JButton btnClose;
	
	//declare combo box
	private JComboBox cb1;
	private JComboBox cb2;
	

	
	// Set data in the drop-down list
	//String[] firstTimeUser = {"Yes","No"};
	//String[] coupon = {"Yes","No"};
	
	
	
	
	private JTextArea textArea;
	private JScrollPane jp;
	
//constructor	
SkiUserGUI() throws FileNotFoundException {
	
	// input validation for n must be checked
	//enter the number
	
	boolean check;
	int n;
	do {
		check = true;
		try {
	n = Integer.parseInt(JOptionPane.showInputDialog("Input the number of Ski customers"));
	if (n <=0 ) {
		JOptionPane.showInputDialog("Invalid Input. Please, enter the number of Ski customers");
	}
	}
	
	catch(NumberFormatException e){
		check = false;
	}
	}while(!check);
	
	
		ski = new SkiResort(n);
	
	
	// call these two methods to create user GUI
	initComponenet();
	doTheLayout();
	
	//btnCreate.addActionListener(this);
	//btnSave.addActionListener(this);
	//btnSort.addActionListener(this);
	//btnClose.addActionListener(this);
	

}



private void initComponenet(){
	// Initialize the GUI components
	lblcustomerName = new JLabel("Customer Name");
	lbldaysOfStay = new JLabel("Days of Stay");
	lblmemberID = new JLabel("Member ID");
	lblnumberOfRentalItems = new JLabel("Rental Items");
	lblcoupons = new JLabel("Coupons");
    lblfirstTimeUser = new JLabel("First Time User");
	
	txtcustomerName = new JTextField(20);
	txtdaysOfStay = new JTextField(5);
	txtmemberID  = new JTextField(10);
	txtnumberOfRentalItems = new JTextField(20);
	
	
	// Create combobox
    JComboBox cb1 = new JComboBox();
    cb1.addItem("yes");
    cb1.addItem("no");
    JComboBox cb2 = new JComboBox();
    cb2.addItem("yes");
    cb2.addItem("no");
    this.setVisible(true);
//	frame.add(cb1, cb2);
//	frame.pack();
	//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//frame.setVisible(true);
	
	// textArea = new JTextArea("Program Output\n", 10,35);
   //  textArea.setEditable(false);
    
    
     jp = new JScrollPane(textArea);
     
     btnCreate = new JButton("Create");
     btnClose = new JButton("Close");
     btnSort = new JButton("Sort");
     btnSave = new JButton("Save");
     JTextArea textArea;
}

private void doTheLayout(){
	// Arrange the UI components into GUI window
	 JPanel pCenter = new JPanel();
     JPanel pSouth = new JPanel();

     JPanel north = new JPanel();
     JPanel center = new JPanel();
     JPanel south = new JPanel();
     
     
     north.add(lblcustomerName);
     north.add(txtcustomerName);
     north.add(lbldaysOfStay);
     north.add(txtdaysOfStay);
     
     center.add(lblmemberID);
     center.add(txtmemberID);
     center.add(lblnumberOfRentalItems);
     center.add(txtnumberOfRentalItems);
     
     south.add(btnCreate);
     south.add(btnSort);
     south.add(btnSave);
     south.add(btnClose);
     
     pCenter.setLayout(new BorderLayout());
     
     pCenter.add(north, BorderLayout.NORTH);
     pCenter.add(center, BorderLayout.CENTER);
     pCenter.add(south, BorderLayout.SOUTH);

     pSouth.add(jp);


   
     this.add(pCenter, BorderLayout.CENTER);
     this.add(pSouth, BorderLayout.SOUTH);
}	
	
 
@Override
public void actionPerformed(ActionEvent e) {
	// calls one of these methods to respond to the user action:

	// TODO Auto-generated method stub
	
	if (e.getSource() == btnCreate)
		btnCreate_Clicked();
	else if (e.getSource() == btnSort)
		btnSort_Clicked();
	else if (e.getSource() == btnSave)
		try {
			btnSave_Clicked();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	else
		btnClose_Clicked();
	


}



private void btnClose_Clicked() {
	// TODO Auto-generated method stub
	System.exit(0);
}



private void display() {
	// TODO Auto-generated method stub
	String output = "Program Output\n"+ "Name\t" + "Days of Stay";
	for (SkiCustomer ski:this.customers) {
		output+= "\n" + ski.toString();
	
	//textArea.setText(output);
}
return output;
}

private void selectionSort() {
	// TODO Auto-generated method stub
	
}



private void btnSave_Clicked() throws FileNotFoundException {
	// TODO Auto-generated method stub
	writeToFile();
}



private void writeToFile() {
	// TODO Auto-generated method stub
	File file = new File("SkiCustomers.txt");
	
	PrintWriter out = new PrintWriter(file);
	
	JOptionPane.showMessageDialog(null, "Writing to a file .....");
	
	for (int i = 0; i < SkiCustomer.getnoSkiCustomers(); i++)
		out.println(ski.toString());
	
	out.close();
	
}



private void btnSort_Clicked() {
	// TODO Auto-generated method stub
	selectionSort();
	display();
}



private void btnCreate_Clicked() {
	// TODO Auto-generated method stub
	
		
		
		display(); 
}




  
  /**Main method*/
  public static void main(String[] args) throws FileNotFoundException{
	  
	  // create the user GUI
	  new SkiUserGUI();
  }
}