package PA06;

public class SkiCustomer {
	
	private String customerName;
	private int daysOfStay;
	private int numberOfRentalItems; //can be only 0,1,2,3

	private String memberID; // this could be null for non-members 
	private	double memberDiscount; // in % from specification
	private	double firstTimeUserDiscount; // in % from specification 
	private double couponDiscountAmount; // from the specifications
	private	double salesTaxAmount; // calculated value 
	private	double totalDiscountAmount; //Calculated value
	private	double totalCharges; // calculated value 
	double rentalAmount;

	private final double SALES_TAX_PERCENTAGE = 0.075;
	private static int noSkiCustomers = 0;
	
	// provide the constructor of this class and you must increment noSkiCustomers data field by 1 in the constructor
	//constructor SkiCustomer
	//first overloaded constructor-- non-member customer
	SkiCustomer(String custName, int daysOfStay, int noOfRentalItems, boolean isFirstTimeUser,
			boolean isCoupon, double rentalAmount){
		this.customerName = custName;
		this.daysOfStay= daysOfStay;
		this.numberOfRentalItems = noOfRentalItems;
		this.rentalAmount = rentalAmount;
	
		double couponDiscountAmount;
		this.couponDiscountAmount= couponDiscountAmount;
		isFirstTimeUser= true;
		isCoupon = true;
		this.firstTimeUserDiscount=0.10;
		
		//set member id null
		int memberID = (Integer) null;
		// initialize member discount to 0%
		double memberDiscount = 0.0;
		//increment noSkiCustomer
	    noSkiCustomers++;
	}
	
	//second overloaded constructor
	SkiCustomer(String custName, int daysOfStay, int noOfRentalItems, boolean isFirstTimeUser,
			boolean isCoupon,String memberID, double rentalAmount){
		this.customerName = custName;
		this.daysOfStay= daysOfStay;
		this.numberOfRentalItems = noOfRentalItems;
		
		this.rentalAmount = rentalAmount;
		
		double couponDiscountAmount;
		this.couponDiscountAmount= couponDiscountAmount;
		
		this.memberID = memberID;
		this.memberDiscount= 0.05;
		
		
		
	}
	
	
	// Add the setter and getter methods
	//get customerName
	public String getcustomerName(){
		return customerName;
	}
	//set customerName
	public void setcustomerName(String customerName) {
		this.customerName = customerName;
	}
	//get daysOfStays
	public int getdaysOfStay() {
		return daysOfStay;
	}
	//set daysOfStay
	public void setdaysOfStay(int daysOfStay) {
		this.daysOfStay = daysOfStay;
	}
	//get numberOfRentalItems
	public int getnumberOfRentalItems() {
		return numberOfRentalItems;
	}
	//set numberOfRentalItems
	public void setnumberOfRentalItems(int numberOfRentalItems) {
		if (this.numberOfRentalItems < 0 &&  this.numberOfRentalItems > 3) throw new IllegalArgumentException("Rental Items are out of range");
		else 
			return;
	}
	//get memberID
	public String getmemberID() {
		return memberID;
	}
	//set memberID
	public void setmemberID(String memberID) {
		this.memberID =memberID;
	}
	//get memberDiscount
	public double getmemberDiscount() {
		return memberDiscount;
	}
	//set memberDiscount
	public void setmemberDiscount(double memberDiscount) {
		this.memberDiscount=memberDiscount;
	}
	//get firstTimeUserDiscount
	public double getfirstTimeUserDiscount() {
		return firstTimeUserDiscount;
	}
	// set firstTimeUserDiscount
	public void setfirstTimeUserDiscount(double firstTimeUserDiscount) {
		this.firstTimeUserDiscount = firstTimeUserDiscount;
	}
	//get couponDiscountAmount
	public double getcouponDiscountAmount() {
		return couponDiscountAmount;
	}
	// set couponDiscountAmount
	public void setcouponDiscountAmount(double couponDiscountAmount) {
		this.couponDiscountAmount = couponDiscountAmount;
	}
	//get salesTaxAmount
	public double getsalesTaxAmount() {
		return salesTaxAmount;
	}
	// set salesTaxAmount
	public void setsalesTaxAmount(double salesTaxAmount) {
		this.salesTaxAmount = salesTaxAmount;
	}
	//get totalDiscountAmount
	public double settotalDiscountAmount() {
		return totalDiscountAmount;
	}
	//set totalDiscountAmount
	public void settotalDiscountAmount(double totalDiscountAmount) {
		this.totalDiscountAmount = totalDiscountAmount;
	}
	//get totalCharges
	public double gettotalCharges() {
		return totalCharges;
		
	}
	//set totalCharges
	public void settotalCharges(double totalCharges) {
		this.totalCharges = totalCharges;
	}
	//get rentalAmount
	public double getrentalAmount() {
		return rentalAmount;
		
	}
	//set rentalAmount 
	public void setrentalAmount(double rentalAmount) {
		this.rentalAmount = rentalAmount;
	}
	// return SALES_TAX_PERCENTAGE
	public final double getSALES_TAX_PERCENTAGE() {
		return SALES_TAX_PERCENTAGE;
	}
	// return noSkiCustomers
	public static int getnoSkiCustomers() {
		return noSkiCustomers;
	}
	
	
	
	
	
	// implement the following methods, you can slightly change the return type of the methods if you like to do that
	
	//calculateMembershipDiscount begin
	private double calculateMembershipDiscount() {
	if 	(memberID != null &&  numberOfRentalItems == 0) {
		this.memberDiscount = 0.05;
	}
	else if(memberID != null &&  numberOfRentalItems == 1){
		this.memberDiscount = 0.08;
	}
	else if(memberID != null &&  numberOfRentalItems == 2){
		this.memberDiscount = 0.08;
	}
	else if(memberID != null &&  numberOfRentalItems == 3){
		this.memberDiscount = 0.08;
	}
	return memberDiscount;
	
	}//end calculateMembershipDiscount
	
	//begin calculateCouponDiscount
	private double calculateCouponDiscount() {
		if(numberOfRentalItems == 0) {
			this.couponDiscountAmount = 5;
			
		}
		else if(numberOfRentalItems == 1 || numberOfRentalItems==2 || numberOfRentalItems==3 ) {
			this.couponDiscountAmount = 10;
		}
		return couponDiscountAmount;
	}//end calculateCouponDiscount
	private double calculateFirstTimeUserDiscount() {
		if (memberID == null && numberOfRentalItems == 0) {
			boolean isFirstTimeUser = true; 
			firstTimeUserDiscount = 0.10;
		}
		else if (memberID == null) {
			if(numberOfRentalItems==1 || numberOfRentalItems==2 || numberOfRentalItems==3) {
			boolean isFirstTimeUser = true; 
			firstTimeUserDiscount = 0.12;
		}
		}
		return firstTimeUserDiscount;
	}
	//this methods calculate the rental amount for the items
		private double calculaterentalAmount(){
			if(numberOfRentalItems==0) {
				rentalAmount = 60;
			}
			else if (numberOfRentalItems==1) {
				rentalAmount = 110;
			}
			else if (numberOfRentalItems==2) {
				rentalAmount = 155;
			}
			else if (numberOfRentalItems==3) {
				rentalAmount = 190;
			}
			return rentalAmount;
		}
	// This method will call 1-3 methods to calculate the total discounts.
	private double calculateDiscount() {
		
		calculateMembershipDiscount();
		calculateFirstTimeUserDiscount();
		calculateCouponDiscount();
		calculaterentalAmount();
		
		totalDiscountAmount = (rentalAmount * (memberDiscount+firstTimeUserDiscount))+couponDiscountAmount;
		return totalDiscountAmount;
	} 
	
	
	
	//calculate sales tax
	private double calculateSalesTax() {
		calculaterentalAmount();
		
		salesTaxAmount =  rentalAmount* SALES_TAX_PERCENTAGE;
		return salesTaxAmount;
	}
	// This method will call 4 and 5 methods to calculate the total charges and set the corresponding instance variables.
	private double calculateTotalCharges() {
		calculateSalesTax();
		calculateDiscount() ;
		totalCharges = rentalAmount  - salesTaxAmount;
		return totalCharges;
	} 
	
	//This method must display the output of the SkiCustomer object
	@Override
	public String toString()
	{ 
		calculateMembershipDiscount();
		calculateFirstTimeUserDiscount();
		calculateCouponDiscount();
		calculaterentalAmount();
		calculateSalesTax();
		calculateTotalCharges();
		return customerName + "\t" + daysOfStay+ "\t" +numberOfRentalItems + "\t" +totalCharges;
		} 

}
