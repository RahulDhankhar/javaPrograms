
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class UserGUI extends JPanel{
	
	private static final long serialVersionUID = 1L;

	static Scraper scraper;
	
	private String url="https://www.rollingstone.com/music/music-lists/500-greatest-songs-of-all-time-151127/smokey-robinson-and-the-miracles-the-tracks-of-my-tears-56465/";
	private String fileName="output.txt";
	GridBagConstraints gbc = new GridBagConstraints();
	//declare and instantiate buttons
	private JButton scrapeSongsButton = new JButton("Scrape");
	private JButton closeButton = new JButton("Close");
	//declare and instantiate combo box
	private JComboBox<String> songCombobox = new JComboBox<String>();

	//declare text area
	private JTextArea songInfoTextArea = new JTextArea(10,35);
	
	static JFrame f;
	
	//constructor user gui
	public UserGUI(){
		
		songCombobox.addItem("Select Song");
		songInfoTextArea.setLineWrap(true);
		doTheLayout();

		//add action listener for button close
		closeButton.addActionListener (new ActionListener () {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		//add action listener for button scrape
		scrapeSongsButton.addActionListener (new ActionListener () {
			public void actionPerformed(ActionEvent e) {

				int itemsCount = songCombobox.getItemCount();
				if(itemsCount>1){
				JOptionPane.showMessageDialog(null, "All the songs are scrapped");
				} else{
					String data ="";
					scraper = new Scraper(url, fileName);

					Scraper.nextURL = url;

					for(int i=0;i<Scraper.songs.length;i++){
						Scraper.songs[i] = scraper.parseData();
						//songInfoTextArea.append(Scraper.songs[i].toString() + "\n");
						//data = data + Scraper.songs[i].toString() + "\n";
						
					}

					for(int i=0;i<Scraper.songs.length;i++){

						if(Scraper.songs[i] !=null)
							songCombobox.addItem(String.valueOf(Scraper.songs[i].getRank()));
					}
					scraper.writeToFile(data);
				}
			}
		});
		
		
		//add action listener for combobox song
		songCombobox.addActionListener (new ActionListener () {
			public void actionPerformed(ActionEvent e) {

				int index = songCombobox.getSelectedIndex();

				if(index!=0){
					int selectedIndex = Integer.parseInt(songCombobox.getSelectedItem().toString());
					Song song =null;
					
					for(int i=0;i<Scraper.songs.length;i++){
						if(Scraper.songs[i] !=null)
							if(selectedIndex == Scraper.songs[i].getRank()){
								song = Scraper.songs[i];
								break;
							}
						}
					

					songInfoTextArea.setText(song.toString());
				}
			}

		});


	}// end constructor UserGUI
	
	private void doTheLayout()
	{

		try {
			// Arrange the UI components into GUI window

			GridBagLayout gbl = new GridBagLayout();
			setLayout(gbl);

			gbc.insets = new Insets(10, 10, 10, 10);

			gbc.gridx = 0;
			gbc.gridy = 0;
			gbc.anchor = GridBagConstraints.CENTER;
			add(songCombobox, gbc);

			gbc.gridx = 0;
			gbc.gridy = 1;
			gbc.anchor = GridBagConstraints.WEST;
			add(songInfoTextArea, gbc);
			
			gbc.anchor=GridBagConstraints.EAST;
			JScrollPane spane = new JScrollPane(songInfoTextArea);
			spane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			spane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
			gbl.setConstraints(spane,gbc);
			JPanel panel = new JPanel(gbl);     
			panel.add(spane);
			add(panel,gbc);

			gbc.gridx = 0;
			gbc.gridy = 3;
			gbc.anchor = GridBagConstraints.WEST;
			add(scrapeSongsButton, gbc);

			gbc.gridx = 0;
			gbc.gridy = 3;
			gbc.anchor = GridBagConstraints.EAST;
			add(closeButton, gbc);


		} catch (Exception e) {

		}

	}// end of Layout method
	
	public static void main (String[] args)  {
		
	       scraper = new Scraper("URL", "filename");
	       
			//Instantiate a JFrame as Scraper
			f = new JFrame("Top 50 Songs Application");
			Container contentPane = f.getContentPane();
			
			//call Constructor UserGUI
			contentPane.add(new UserGUI());
			f.pack();
			
			//Set Position to the Center of the Screen
			f.setLocationRelativeTo(null);
			f.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
			
			// set resizable false
			f.setResizable(false);
			
			// make frame visible
			f.setVisible(true);
	       
	       
	    } // end main 
	
}// end class