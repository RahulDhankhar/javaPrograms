
public class Song {

	private int rank;
	private String writer;
	private String producer;
	private String releaseDate;
	
	private String url;
	private String description;
	private static int remaingObjects = 50;
	
	public Song(int rank, String writer, String producer, String releaseDate, String url, String description) {
		this.rank = rank;
		this.writer = writer;
		this.producer = producer;
		this.releaseDate = releaseDate;
		this.url = url;
		this.description = description;
		remaingObjects--;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String pDescription) {
		description=pDescription;
	}
	
	
	public int getRank() {
		return rank;
	}
	public void setRank(int pRank) {
		rank=pRank;
	}
	
	public String getWriter() {
		return writer;
	}
	public void setWriter(String pWriter) {
		writer=pWriter;
	}
	
	public String getProducer() {
		return producer;
	}
	public void setProducer(String pProducer) {
		producer=pProducer;
	}
	
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String pReleaseDate) {
		releaseDate=pReleaseDate;
	}
	
	public String getURL() {
		return url;
	}
	public void setURL(String pURL) {
		url=pURL;
	}
	
	@Override
	public String toString() {
		return "Song [rank=" + rank + ", writer=" + writer + ", producer=" + producer + ", releaseDate=" + releaseDate
				+ ", url=" + url + ", description=" + description + "]";
	}

	public static int getRemaingObjects() {
		return remaingObjects;
	}

	public static void setRemaingObjects(int remaingObjects) {
		Song.remaingObjects = remaingObjects;
	}
}
