
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

public class Scraper{
	
	private String url; 
	private String fileName;
	public static Song[] songs = new Song[50];
	
	// Rank Pattern 
	private Pattern rankPattern = Pattern.compile("<span><class>(.*?) </span>");

	// Writer Pattern
	private Pattern writerPatern = Pattern.compile("<p><strong>(.*?)<br>");
	private Pattern writerPatern2 = Pattern.compile("<p><strong>(.*?)</strong>(.*?)<br>");
	
	// To find the Next URL of the Song
	private Pattern nextURLPattern = Pattern.compile("link rel=\"next\" href=\"(.*?)");

	// Song Description Pattern
	private Pattern descriptionPattern = Pattern.compile("<p> rel=\"nofollow\" href=\"(.*?)</p>");
	
	// Matcher object
	private Matcher matcher;

	public static String nextURL="";
	public static String currentURL="";
	
	Scraper(String url, String fileName){
		this.url = url;
		this.fileName = fileName;
	}
	
	
	
	// this method will parse a song data (starting from the first URL), and it creates song objects for each song URL
	// it adds the new Song object to the array of Song objects, songs 
	
	public Song parseData() {
		String rank="";
		String writer="";
		String producer="";
		String releaseDate="";
		String description="";
		String url="";
		
		Song song = null;

		boolean desc=false;

		currentURL = nextURL;
		
		try{
			URL url1 = new URL(nextURL);
			URLConnection uc = url1.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(
					uc.getInputStream(), "UTF-8"));
			String inputLine;
			StringBuilder a = new StringBuilder();

			while ((inputLine = in.readLine()) != null){
				a.append(inputLine + "\n");
				// match for rank pattern
				matcher= rankPattern.matcher(inputLine);

				if(matcher.find()){
					rank = matcher.group(1).substring(0,2);
					if(rank.contains(".")){
						rank = rank.substring(0,1);
					}
				}
				
				// match for writer pattern
				matcher = writerPatern.matcher(inputLine);
				if(matcher.find()){
					writer=matcher.group(1).substring(17,matcher.group(1).length()).replaceAll(">", "").trim();
					if(writer.contains("<br")){
						writer = writer.substring(0, writer.indexOf("<br>"));
					}
					
					// replace html keyword with a blank space
					writer = writer.replaceAll("&<b>([^<]*)</b>", "");


					String[] split = inputLine.trim().split("<br>");
					for(int i=1;i<split.length;i++){

						if(i==1){
							int index = split[i].indexOf("</strong>");

							producer=split[i].substring(index + "</strong>".length(), split[i].length()).replaceAll("<b>([^<]*)</b>", "");

							}
						
						else if(i==2){

							split[i] = split[i].trim().replace("<b>([^<]*)</b>;", "'");
							int index = split[i].indexOf("</strong>");


							if(releaseDate.equals("")){
								releaseDate=split[i].substring(index + "</strong>".length(), split[i].length());

								releaseDate = releaseDate.trim();

								String[] dateSplit = releaseDate.split(",");
								releaseDate = dateSplit[0];
							}

						}
					}
				}
				
				// match patterns for Description
				matcher = descriptionPattern.matcher(inputLine);

				if(desc == true){
					description = inputLine.trim();
					desc = false;
					
					description = description.replaceAll("<b>([^<]*)</b>", "'");

					//to fetch the First 15 characters for songs description
					description = description.substring(0, 15);

				}

				if(matcher.find()){
					desc = true;
				}
				matcher = nextURLPattern.matcher(inputLine);

				if(matcher.find()){

					nextURL = inputLine.trim();

					int index = nextURL.indexOf("href=\"");

					nextURL = nextURL.substring(index + "href=\"".length(), nextURL.length()-4);

					nextURL = "http:" + nextURL;
					this.url = nextURL;


				}

				if(writer.equals("")){
					matcher = writerPatern2.matcher(inputLine);

					if(matcher.find()){
						writer=matcher.group(1).substring(17,matcher.group(1).length()).replaceAll(">", "").trim();

						if(writer.contains("<br")){
							writer = writer.substring(0, writer.indexOf("<br"));
						}
						writer = writer.replaceAll("<b>([^<]*)</b>;", "");
						String[] split = inputLine.trim().split("<br>");
						for(int i=1;i<split.length;i++){
							if(i==1){

								int index = split[i].indexOf("</strong>");
								producer=split[i].substring(index + "</strong>".length(), split[i].length()).replaceAll("<b>([^<]*)</b>;", "");

							} else if(i==2){
								split[i] = split[i].trim().replace("<b>([^<]*)</b>;", "'");
								int index = split[i].indexOf("</strong>");

								if(releaseDate.equals("")){
									releaseDate=split[i].substring(index + "</strong>".length(), split[i].length());

									releaseDate = releaseDate.trim();

									String[] dateSplit = releaseDate.split(",");
									releaseDate = dateSplit[0];
								}

							}
						}

					}
				}


			}
			in.close();

			return song;

		}catch(Exception e){

			e.printStackTrace();

		}
		return song;
	}
	
	// will read the data from songs array (one by one) and return a String of the all Song object strings in multiple lines, each line has a Song object String
	@Override
	public String toString() {
		return "Scrapper [URL=" + url + ", FileName=" + fileName + "]";
	}
	
	// store the program out in a text file, output.txt 
	public void writeToFile(String data) {
		try{

			// time stamp
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());

			// time stamp formatting
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
			String filename ="output" + sdf.format(timestamp) + ".txt";

			File file =new File(fileName);
			FileWriter fileWritter = new FileWriter(file.getName(),true);
			BufferedWriter bufferWritter = new BufferedWriter(fileWritter);

			bufferWritter.write(data);

			// Close the BufferedWriter 
			bufferWritter.close();
			JOptionPane.showMessageDialog(null, "Output Written to " + filename);
		}catch(Exception e){

		}
	}
	
    }//end Class
	

