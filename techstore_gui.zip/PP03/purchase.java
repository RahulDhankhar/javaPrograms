package PP03;
public class purchase {
	private String categoryName;
	private int amount;
	private String purchaseDate;
	static int numberOfPurchase =0;
	private product product1;
	
	//constructor purchase
	purchase(String categoryName, product product1,int amount, String purchaseDate){
		this.categoryName= categoryName;
		this.product1 = product1;
		this.amount = amount;
		this.purchaseDate =purchaseDate;
		numberOfPurchase++;
	}
	//getters and setters
	//get Product1
	public product getProduct() {
		return product1;
	}
	//set product1
	public void setProduct(product product1) {
		this.product1=product1;
	}
	//get amount
	public int getAmount() {
		return amount;
	}
	
	//set amount
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	//get purchase date
	public String getPurchaseDate() {
		return purchaseDate;
	}
	//set purchase date
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	//get category name
	public String getCategoryName() {
		return categoryName;
	}
	//set category name
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	//get number of purchase
	public static int getNumberOfPurchase() {
		return numberOfPurchase;
	}
	//set number of purchase
	public static void setNumberOfPurchase(int numberOfPurchase) {
		purchase.numberOfPurchase = numberOfPurchase;
	}
	
	//return purchase info
	@Override
	public String toString() {
		String purch = "";
		purch= "Cateogry :"+categoryName+"Product: "+this.product1.getName()+ "Amount: "+this.amount+"Date: "
				+ ""+purchaseDate;
		return purch;
	}
}
