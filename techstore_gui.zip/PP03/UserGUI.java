package PP03;

	import java.awt.Container;
	import java.awt.GridBagConstraints;
	import java.awt.GridBagLayout;
	import java.awt.Insets;
	import java.awt.event.ActionEvent;
	import java.awt.event.ActionListener;
	import java.text.DateFormat;
	import java.text.SimpleDateFormat;
	import java.util.Date;
	import javax.swing.JButton;
	import javax.swing.JComboBox;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JOptionPane;
	import javax.swing.JPanel;
	import javax.swing.JScrollPane;
	import javax.swing.JTextArea;
	import javax.swing.JTextField;
	import javax.swing.ScrollPaneConstants;



public class UserGUI extends JPanel {

		GridBagConstraints gbc = new GridBagConstraints();
		
		// declare UI component objects

		// Declare Labels
		private JLabel categoryLabel;
		private JLabel customerLabel ;
		private JLabel productLabel;
		private JLabel infoLabel;
		private JLabel dateLabel;
		private JLabel transactionsLabel;
		private JLabel amountLabel;


		//Declare Combo Boxes
		private JComboBox<String> categoryComboBox;
		private JComboBox<String> customerComboBox;
		private JComboBox<String> productComboBox;


		//Declare Text Areas
		private JTextArea infoTextArea;
		private JTextArea transactionTextArea;

		//Declare Text Fields
		private JTextField amountTextField;
		private JTextField dateTextField;


		//Declare the Buttons
		private JButton exitButton;
		private JButton buyButton;


		//Declare User Interface Components
		private techStore techStore;

		//declare File name
		private String fileName = "data.txt";

		static JFrame f;
		//begin constructor UserGUI
		public UserGUI() {
			//Instantiate a new Object of TechStore
			techStore = new techStore(fileName);

			//Reading the File
			techStore.readFile();

			//Instantiate User Interface Components
			initGUI();

			productComboBox.addItem("Select Product");
			customerComboBox.addItem("Select Customer");
			categoryComboBox.addItem("Select Category");

			for(int i=0;i<techStore.getCategories().length;i++){

				// Check for null
				if(techStore.getCategories()[i]!=null)
					
					categoryComboBox.addItem(techStore.getCategories()[i].getName());
			}
			
			for(int i=0;i<techStore.getCustomers().length;i++){
				
				if(techStore.getCustomers()[i]!=null){
					customerComboBox.addItem(techStore.getCustomers()[i].getfName() + " " + techStore.getCustomers()[i].getlName());
				}
			}
			doTheLayout();
			
			//add action listner for category combo box
           categoryComboBox.addActionListener (new ActionListener () {
				public void actionPerformed(ActionEvent e) {
					//get category name
					String category = categoryComboBox.getSelectedItem().toString();
					//get product count
					int productCount = productComboBox.getItemCount();

					for(int j=0;j<productCount;j++){

						try{
							productComboBox.removeItemAt(0);
						}catch(Exception ex){
							System.out.println(ex);
						}
					}

					if(categoryComboBox.getSelectedIndex() !=0){

						product[] products = techStore.getProducts(category);

						productComboBox.addItem("Select Product");

						for(int x=0;x<products.length;x++){
							if(products[x]!=null){
								productComboBox.addItem(products[x].getName());
							}
						}
					} else{

						productComboBox.addItem("Select Product");
					}
				}
			});
           
         //add action listner for product combo box
             productComboBox.addActionListener (new ActionListener () {
				public void actionPerformed(ActionEvent e) {

					if(productComboBox.getSelectedItem()!=null){

						if(productComboBox.getSelectedIndex()!=0){

							String product = productComboBox.getSelectedItem().toString();
							String category = categoryComboBox.getSelectedItem().toString();
							
							product prod = techStore.getProduct(category, product);
							
							if(prod!=null)
								infoTextArea.setText(prod.toString());
						} else{
							infoTextArea.setText("");

						}
					}
				}
			});
        
             //add action listner for customer combo box
       customerComboBox.addActionListener (new ActionListener () {
				public void actionPerformed(ActionEvent e) {
					if(customerComboBox.getSelectedItem()!=null){
						customer customer = null;
						String name = customerComboBox.getSelectedItem().toString();

						customer = techStore.getCustomer(name);

						String transactionDisplay ="";
						if(customer!=null){

							for(int i=0;i<customer.getPurchases().length;i++){

								if(customer.getPurchases()[i]!=null){

									transactionDisplay = transactionDisplay + 
											customer.getPurchases()[i].toString() + "\n";
									}

							}
							transactionTextArea.setText(transactionDisplay);
						}

					} else{
						transactionTextArea.setText("");
					}
				}
			});
       // add action listner for button exit
        exitButton.addActionListener (new ActionListener () {
				public void actionPerformed(ActionEvent e) {

					System.exit(0);
				}
			});
     // add action listner for button buy
       buyButton.addActionListener (new ActionListener () {
				public void actionPerformed(ActionEvent e) {

					boolean validate = validateDataForBuy();

					if(validate){

						customer customer =null;
						String categoryName = categoryComboBox.getSelectedItem().toString();
						String productName = productComboBox.getSelectedItem().toString();
						int amont = Integer.parseInt(amountTextField.getText().toString());
						String date = dateTextField.getText().trim();
						String name = customerComboBox.getSelectedItem().toString();

						customer = techStore.getCustomer(name);
						
						product p =techStore.getProduct(categoryName, productName);

						techStore.addPurchase(customer, categoryName, p, amont, date);

						JOptionPane.showMessageDialog(null, "Thanks! Purchase is done. Please, check transcation area for details.");

						String transaction ="";
						transaction = "purchase; " + customer.getId() + "; " + categoryName + "; "+ p.getId() + "; " + amont +"; " + date;

						techStore.writeFile(transaction);

						if(customerComboBox.getSelectedItem()!=null){
							for(int i=0;i<techStore.getCustomers().length;i++){

								if(techStore.getCustomers()[i] !=null){
									if(name.equals(techStore.getCustomers()[i].getfName() + " " + techStore.getCustomers()[i].getlName())){
										customer = techStore.getCustomers()[i];
										break;
									}
								}
							}

							String transactionDisplay ="";
							if(customer!=null){

								for(int i=0;i<customer.getPurchases().length;i++){

									if(customer.getPurchases()[i]!=null){
										transactionDisplay = transactionDisplay + customer.getPurchases()[i].toString() + "\n";

									}

								}

								transactionTextArea.setText(transactionDisplay);
							}


						}

					}

				}



            private boolean validateDataForBuy() {
					boolean validate = true;

					if(categoryComboBox.getSelectedIndex() == 0){
						JOptionPane.showMessageDialog(null, "Select category");
						validate = false;

					} else if(customerComboBox.getSelectedIndex() == 0){
						JOptionPane.showMessageDialog(null, "Select customer");
						validate = false;
					}else if(productComboBox.getSelectedIndex() == 0){
						JOptionPane.showMessageDialog(null, "Select product");
						validate = false;
					} else if(!checkIntegr(amountTextField.getText().trim(), "Amount")){
						//JOptionPane.showMessageDialog(null, "Enter amount as integer");
						validate = false;
					} else if(dateTextField.getText().toString().equals("")){
						JOptionPane.showMessageDialog(null, "Enter date");
						validate = false;
					} else if(!(validateDate(dateTextField.getText().toString()))){
						JOptionPane.showMessageDialog(null, "Enter valid date, correct format (MM/dd/yyyy)");
						validate = false;
					}

					return validate;
				}


private boolean validateDate(String inputDate) {

					boolean validate = true;
					try {
						DateFormat format = new SimpleDateFormat("MM/dd/yyyy");
						format.setLenient(false);
						Date date = format.parse(inputDate);


					} catch (Exception e) { 
						validate = false;
					}
					return validate;
				}
			});

			infoTextArea.setEditable(false);
			transactionTextArea.setEditable(false);
			infoTextArea.setLineWrap(true);
			transactionTextArea.setLineWrap(true);
		} // end constructor UserGUI

private void initGUI() {
	// Initialize the GUI components
			//Instantiate Labels
			categoryLabel = new  JLabel("Category");
			customerLabel = new  JLabel("Customer");
			productLabel = new  JLabel("Product");
			infoLabel = new  JLabel("Info:");
			dateLabel = new  JLabel("Date");
			transactionsLabel = new  JLabel("Transactions");
			amountLabel = new  JLabel("Amount");


			//Instantiate Combo boxes
			categoryComboBox = new JComboBox<String>();
			customerComboBox = new JComboBox<String>();
			productComboBox = new JComboBox<String>();

			//Instantiate Text area with number of rows and columns
			infoTextArea = new JTextArea(5,20);
			transactionTextArea = new JTextArea(5,30);

			//Instantiate Text fields with its width
			amountTextField = new JTextField(5);
			dateTextField = new JTextField(10);


			//Instantiate Buttons
			exitButton = new JButton("Exit");
			buyButton = new JButton("Buy");
		}




//begin method layout
private void doTheLayout()
		{
	// Arrange the UI components into GUI window

			try {

				GridBagLayout gbl = new GridBagLayout();
				setLayout(gbl);

				gbc.insets = new Insets(10,10,10,10);

				gbc.gridx = 0;
				gbc.gridy = 0;
				gbc.anchor = GridBagConstraints.EAST;
				add(categoryLabel, gbc);


				gbc.gridx = 1;
				gbc.gridy = 0;
				gbc.anchor = GridBagConstraints.EAST;
				add(categoryComboBox, gbc);

				gbc.gridx = 2;
				gbc.gridy = 0;
				gbc.anchor = GridBagConstraints.EAST;
				add(customerLabel, gbc);

				gbc.gridx = 3;
				gbc.gridy = 0;
				gbc.anchor = GridBagConstraints.EAST;
				add(customerComboBox, gbc);

				gbc.gridx = 0;
				gbc.gridy = 1;
				gbc.anchor = GridBagConstraints.EAST;
				add(productLabel, gbc);
				
				gbc.gridx = 1;
				gbc.gridy = 1;
				gbc.anchor = GridBagConstraints.EAST;
				add(productComboBox, gbc);

				gbc.gridx = 0;
				gbc.gridy = 2;
				gbc.anchor = GridBagConstraints.EAST;
				add(infoLabel, gbc);


				gbc.gridx = 1;
				gbc.gridy = 3;
				gbc.anchor = GridBagConstraints.WEST;
				add(infoTextArea, gbc);
				
				//add scroll bar
				gbc.anchor=GridBagConstraints.EAST;
				JScrollPane spane = new JScrollPane(infoTextArea);
				spane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				spane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
				gbl.setConstraints(spane,gbc);
				JPanel panel = new JPanel(gbl);     
				panel.add(spane);
				add(panel,gbc);


				gbc.gridx = 2;
				gbc.gridy = 2;
				gbc.anchor = GridBagConstraints.WEST;
				add(amountLabel, gbc);


				gbc.gridx = 3;
				gbc.gridy = 2;
				gbc.anchor = GridBagConstraints.WEST;
				add(amountTextField, gbc);

				gbc.gridx = 2;
				gbc.gridy = 3;
				gbc.anchor = GridBagConstraints.WEST;
				add(dateLabel, gbc);


				gbc.gridx = 3;
				gbc.gridy = 3;
				gbc.anchor = GridBagConstraints.WEST;
				add(dateTextField, gbc);

				gbc.gridx = 3;
				gbc.gridy = 4;
				gbc.anchor = GridBagConstraints.WEST;
				add(buyButton, gbc);

				gbc.gridx = 0;
				gbc.gridy =4;
				gbc.anchor = GridBagConstraints.WEST;
				add(transactionsLabel, gbc);

				gbc.gridx = 1;
				gbc.gridy = 6;
				gbc.anchor = GridBagConstraints.WEST;
				add(transactionTextArea, gbc);

				gbc.gridx = 1;
				gbc.gridy = 7;
				gbc.anchor = GridBagConstraints.EAST;
				add(exitButton, gbc);


				gbc.weightx = 1;
				gbc.fill = GridBagConstraints.HORIZONTAL;
				gbc.anchor = GridBagConstraints.CENTER;
				gbc.gridwidth = 5;
				gbc.gridx=0;
				gbc.gridy=6;
				gbc.anchor=GridBagConstraints.NORTH;
				add(transactionTextArea,gbc);
				 
				//add scroll bar
				gbc.anchor=GridBagConstraints.EAST;
				JScrollPane spane1 = new JScrollPane(transactionTextArea);
				spane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
				spane1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
				gbl.setConstraints(spane1,gbc);
				JPanel panel1 = new JPanel(gbl);     
				panel1.add(spane1);
				add(panel1,gbc);






			} catch (Exception e) {

			}

		}// end method Layout



private static boolean checkIntegr(String str, String validateType) {

			boolean validate = true;

			try{
				
				int  value =Integer.parseInt(str);

				if(value<=0.0){
					JOptionPane.showMessageDialog(null, validateType + " must be greater than zero", "Input read error",JOptionPane.ERROR_MESSAGE);
					validate = false;
				}



			} catch(Exception e){

				JOptionPane.showMessageDialog(null, "Enter integer value for " + validateType, "Input read error",JOptionPane.ERROR_MESSAGE);
				validate = false;

			}
			return validate;

		}
//begin main method
public static void main(String[] args) {


			//Instantiate a JFrame as Tech-Store
			f = new JFrame("Tech-Store");
			Container contentPane = f.getContentPane();


			//call Constructor UserGUI
			contentPane.add(new UserGUI());
			f.pack();
			
			//Set Position to the Center of the Screen
			f.setLocationRelativeTo(null);
			f.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
			
			// set resizable false
			f.setResizable(false);
			
			// make frame visible
			f.setVisible(true);

		}// end main

}

