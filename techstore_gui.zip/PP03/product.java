package PP03;

public class product {
	private int id;
	private String name;
	private String description;
	private double price;
	static int numberOfProducts = 0;
	product (int id, String name, String description, double price){
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		numberOfProducts++;
	}
	
	//add getters and setters
	//get id
	public int getId() {
		return id;
	}
	//set id
	public void setId(int id) {
		this.id = id;
	}
	//get name
	public String getName() {
	return name;
	}
	//set name
	public void setName(String name) {
		this.name = name;
	}
	//get description
	public String getDescription() {
		return description;
	}
	//set description
	public void setDescription(String description) {
		this.description= description;
	}
	//get price
	public double getPrice() {
		return price;
	}
	//set price
	public void setPrice(double price) {
		this.price = price;
	}
	//get number of products
	public static int getNumberOfProducts() {
		return numberOfProducts;
	}
	//set number of products
	public static void setNumberOfProducts(int numberOfProducts) {
		product.numberOfProducts = numberOfProducts;
	}
	
	//return product info
	public String toString() {
		return "Product ID: "+id+"Product name: "+name+"Product description: "+ description+ "Price: "+price;
	}

}
