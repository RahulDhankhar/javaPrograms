package PP03;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class techStore {
	private customer[] customers;
	private category[] categories;
	private String fileName;
	
	//getters and setters
	//get customers
	public customer[] getCustomers() {
		return customers;
	}
	//set customers
	public void setCustomers(customer[] customers) {
		this.customers = customers;
	}
	//get categories
	public category[] getCategories() {
		return categories;
	}
	//set categories
	public void setCategories(category[] categories) {
		this.categories = categories;
	}
	//get fileName
	public String getFileName() {
		return fileName;
	}
	//set fileName
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	// constructor techStroe
	public techStore (String fileName) {
		this.customers = new customer[10];
		this.categories = new category[10];
		this.setFileName(fileName);
		
	}
	
	public void addCustomer(String fName, String lName, int id) {
		// Creates and adds a new Customer object to the customers array
		for(int i=0;i<this.customers.length;i++){

			//Check for null
			if(this.customers[i] == null){
				this.customers[i] = new customer(fName, lName, id);
				break;
			}
		}
	}
	

	public void addCategory (String name) {
		// Creates and adds a new Category object to the categories array
		for(int i=0;i<this.categories.length;i++){
			//Check for any null  values in category
			if(this.categories[i] == null){
				this.categories[i] = new category(name);
				break;
			}
		}
	}
	
	public void addPurchase(customer customer, String categoryName, product p, int amount, String date) {
		// calls customer object to purchase a product
		for(int i=0;i<this.customers.length;i++){
			if(this.customers[i] !=null){
				if(this.customers[i].getId() == customer.getId()){
					this.customers[i].addPurchases(categoryName, p, amount, date);
				}
			}
		}
	}
	
	//begin addProduct
	public void addProduct(String categoryName, int id, String name, String description, double price) {
		// Adds a product object to Category object that matches the categoryName parameter
		
		for(int i=0;i<this.categories.length;i++){
			boolean setProduct = false;
			// product matches in cateogory
			if(categoryName.equals(this.categories[i].getName())){
				product[] products = this.categories[i].getProducts();
				
				for(int j=0;j<products.length;j++){
				if(products[j] == null){
					products[j] = new product(id, name, description, price);
					setProduct = true;
					break;
				}
			}
				this.categories[i].setProducts(products);
		}
			if(setProduct == true)
				break;
	}
	}// end addProduct
	
	//begin getCustomer
	public customer getCustomer(String name){
		// search for a Customer object by customer name in the customers array
	customer customer1 = null;

		for(int i=0;i<this.customers.length;i++){
			if(this.customers[i] !=null){
				if(name.equals(this.customers[i].getfName() + " " + this.customers[i].getlName())){
					customer1 = this.customers[i];
					break;
				}
			}
		}
		return customer1;
	}// end getCustomer
	
	
	public customer getCustomer(int customerID){
		// search for a Customer object by customer id in the customers array 
		customer customer1 = null;

		for(int i=0;i<this.customers.length;i++){

			if(this.customers[i] !=null){
				if(customerID == this.customers[i].getId()){
					customer1 = this.customers[i];
					break;
				}
			}
		}
		return customer1;
	}
	
	//begin get category
	public category getCategory(String categoryName){
		// search for a Category object by category name in the purchases array
		category category = null;
		for(int i=0;i<this.categories.length;i++){
			if(this.categories[i]!=null){
				if(categoryName.equals(this.categories[i].getName())){
					category = this.categories[i];

				}
			}
		}
		return category;
	}// end get category
	
	//begin getProducts
	public product[] getProducts(String categoryName) {
		// returns an array of Product objects for a Category object that matches the 'categoryName' parameter 
		category category1 = null;

		for(int i=0;i<this.categories.length;i++){
			if(this.categories[i]!=null){
				if(categoryName.equals(this.categories[i].getName())){
					category1 = this.categories[i];

				}
			}
		}
		return category1.getProducts();
	}
	
	public product getProduct(String categoryName, String productName) {
		// returns a Product object with name matches the productName parameter in a Category object that matches the 'categoryName' parameter 
		product p = null;
		for(int i=0;i<this.getCategories().length;i++){

			//Check for null
			if(this.getCategories()[i]!=null){

				if(categoryName.equals(this.getCategories()[i].getName())){

					for(int j=0;j<this.getCategories()[i].getProducts().length;j++){

						if(this.getCategories()[i].getProducts()[j]!=null){

							if(productName.equals(this.getCategories()[i].getProducts()[j].getName()))
							{

								p = this.getCategories()[i].getProducts()[j];
								
								break;
							}

						}
					}
				}
			}
		}
		return p;
	}
	
	public product getProduct(String categoryName, int productID) {
		// returns a Product object with id matches the productID parameter in a Category object that matches the 'categoryName' parameter 
		product p = null;
		for(int i=0;i<this.getCategories().length;i++){

			//Check for null
			if(this.getCategories()[i]!=null){
				if(categoryName.equals(this.getCategories()[i].getName())){
					for(int j=0;j<this.getCategories()[i].getProducts().length;j++){

						if(this.getCategories()[i].getProducts()[j]!=null){

							if(productID == this.getCategories()[i].getProducts()[j].getId())
							{
								p = this.getCategories()[i].getProducts()[j];
							
								break;
							}

						}
					}
				}
			}
		}
		return p;
	}
	
	
	@SuppressWarnings("resource")
	public void readFile() {
		// read data from the data.txt file and instantiate all project objects (arrays).
				// some object arrays are in other objects such as customer and category classes
				// it creates object for each string data in the input file, line by line
		try{
			BufferedReader br = null;

			br = new BufferedReader(new FileReader("data.txt"));

			String sCurrentLine="";

			while ((sCurrentLine = br.readLine()) != null) {
				if(sCurrentLine.startsWith("customer")){

					String[] customerSplit = sCurrentLine.split(";");

					
					String fName = customerSplit[1].trim();
					String lName = customerSplit[2].trim();
					String id = customerSplit[3].trim();

					
					addCustomer(fName, lName, Integer.parseInt(id));



				} else if(sCurrentLine.startsWith("category")){

					String[] categorySplit = sCurrentLine.split(";");

					String category = categorySplit[1].trim();

					addCategory(category);


				} else if(sCurrentLine.startsWith("product")){

					String[] productSplit = sCurrentLine.split(";");


					String category = productSplit[1].trim();

					int id = Integer.parseInt(productSplit[2].trim());
					String name = productSplit[3].trim();
					String description = productSplit[4].trim();
					double price = Double.parseDouble(productSplit[5].trim());

					addProduct(category, id, name, description, price);




				} else if(sCurrentLine.startsWith("purchase")){
					
					String[] purchaseSplit = sCurrentLine.split(";");

					String customerid = purchaseSplit[1].trim();

					for(int i=0;i<this.customers.length;i++){
						boolean setPurchase = false;

						if(customerid.equals(String.valueOf(this.customers[i].getId()))){

							String categoryName = purchaseSplit[2].trim();
							String productid = purchaseSplit[3].trim();


							product product = null;

							product = getProduct(categoryName, Integer.parseInt(productid));
							int amount = Integer.parseInt(purchaseSplit[4].trim());
							String purchaseDate = purchaseSplit[5].trim();
							
							purchase[] purchases = this.customers[i].getPurchases();

							for(int k=0;k<purchases.length;k++){

								if(purchases[k] == null){

									purchases[k] = new purchase(categoryName, product, amount, purchaseDate);

									setPurchase = true;

									break;
								}
							}

							this.customers[i].setPurchases(purchases);
						}

						if(setPurchase == true)
							break;
					}


				}
			}
		}
		catch(Exception e){

			System.out.println(e);

		}
	}
	
	public void writeFile(String transaction) {
		// write/append any new transaction (purchase) data to the data.txt file
		try{
			File file =new File("data.txt");
			FileWriter fileWritter = new FileWriter(file.getName(),true);
			BufferedWriter bufferWritter = new BufferedWriter(fileWritter);

			bufferWritter.write("\n"+transaction);

			bufferWritter.close();
		}catch(Exception e){

		}
	}
	
}
