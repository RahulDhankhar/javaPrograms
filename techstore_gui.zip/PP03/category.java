package PP03;
public class category {
	private String name;
	static int numberOfCategories = 0;
	
	//constructor category
	category(String name) {
		this.name = name;
		this.products = new product[12];
		numberOfCategories++;
	
	}
	
	public product[] products;
	
	//setter and getter methods
    //get name
	public String getName() {
		return name;
	}
	//set name
	public void setName(String name) {
		this.name =name;
	}
	//get products
	public product[] getProducts() {
		//returns all the products objects with the current category object
		return products;
	}
	
	//set products
	public void setProducts(product[] products) {
		this.products =products;
	}
	
	//adds new product to the array products
	public boolean addProduct(int id, String name,String description, double price){
		// adds a new product to the products array, 
		//and it returns true if the product is added (the product does not exist before), false otherwise
		// it must call getProduct() to check if the product exist in the array
		boolean addProduct = false;
		 product[] products = this.getProducts();
		 for(int i=0;i<products.length;i++) {
			 if(products[i]==null) {
				 products[i]=new product(id,name,description,price);
			 break;
			 }
		 }
		 this.setProducts(products);
		return addProduct;
	}
	
	//get product by searching for product id
	public product getProduct(int productID) {
		// searches for a product in the product array by product id
		product p = null;
		for(int i = 0; i<products.length;i++) {
			if(productID == this.products[i].getId()) {
				p = this.products[i];
			}
		}
		return p;
	}
	//get product by searching for product
	public product getProduct(String productName) {
		// searches for a product in the product array by product name
		product p = null;
		for(int i =0; i<products.length;i++) {
			if(productName.equals(this.products[i].getName())) {
				p = this.products[i];
			}
		}
		return p;
	}
	
}
