package PP03;

import java.util.Arrays;

public class customer {
	private String fName; 
	private String lName;
	private int id;
	private purchase[] purchases;
	static int numberOfCustomers = 0;
	
	//getters and setters
	
	//get first name
	public String getfName() {
		return fName;
	} 
	//set first name
	public void setfName(String fName) {
		this.fName=fName;
	}
	//get last name
	public String getlName() {
		return lName;
	}
	//set last name
	public void getlName(String lName) {
		this.lName = lName;
	}
	//get customer id
	public int getId() {
		return id;
	}
	//set customer id
	public void setId(int id) {
		this.id = id;
	}
	//get purchases
	public purchase[] getPurchases() {
		return purchases;
	}
	//set purchases
	public void setPurchases(purchase[] purchases) {
		this.purchases = purchases;
	}
	
	//constructor customer
	customer(String fName, String lName, int id){
		this.fName=fName;
		this.lName = lName;
		this.id = id;
		numberOfCustomers++;
		purchases = new purchase[15];
		
	}
	

public  purchase addPurchases(String categoryName, product p, int amount, String date){
	// makes a purchase for a product, it creates a new purchase object that has the purchase information.
	// the new purchase object information must be written to the data text file using the returned Purchase object of this method.
	// the new purchase object must be added to the purchases array

		//get purchase list to customer
		purchase[] purchases = this.getPurchases();
		purchase Purchase =null;
		
		for(int j=0;j<purchases.length;j++) {
			//check purchase, if null
			if(purchases[j]== null) {
				//instailize purchase object
				Purchase = new purchase (categoryName, p,amount,date);
				purchases[j] = Purchase;
				break;
			}
		}
		this.setPurchases(purchases);
		return Purchase;
	}
	
public double totalPurchase() {
	// searches and returns a Purchase object in the purchases array using a product id 
		double totalPurchase =0.0;
		for(int i=0;i<purchases.length;i++) {
		totalPurchase = totalPurchase + purchases[i].getAmount();
		}
		return totalPurchase;
	}
@Override
public String toString() {
	// it must return string of customer object info and all purchases' objects info
	return "Customer [fName=" + fName + ", lName=" + lName + ", id=" + id
			+ ", purchases=" + Arrays.toString(purchases) + "]";
}

}
