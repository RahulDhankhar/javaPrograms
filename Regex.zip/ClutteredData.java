import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;


public class ClutteredData extends JPanel {
	
	GridBagConstraints gbc = new GridBagConstraints();
	
	//declare labels
	private JButton repairButton;
	private JButton sortButton;
	private JButton saveButton;
	private JButton closeButton;
	
	
	//declare text area
	static JTextArea outputTextArea;
	
	static JFrame f;
	
	
	static Pattern phonePattern = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
	static Pattern emailPattern = Pattern.compile("^[!#$%&'*+-/=?^_`{|}~a-zA-Z0-9._&]+@[a-zA-Z0-9.]+$");
	static Pattern webPattern = Pattern.compile("(http|https)(://www.)?([a-zA-Z0-9]+).[a-z]*.[a-z]{3}");
	static Matcher phoneMatcher;
	static Matcher urlMatcher;
	static Matcher emailMatcher;
	public static String fileName;
	private static ArrayList<String[]>readData1;
	
	
	
	//constructor Cluttereddata
	public ClutteredData(String fileName) {
		this.fileName = fileName;
		
		initComponent();
		doTheLayout();
		
		
		//add action listener for button repair
		repairButton.addActionListener (new ActionListener () {
			public void actionPerformed(ActionEvent e) {
				repairData(fileName);
			}
		});
		
		//add action listener for button sort
		sortButton.addActionListener (new ActionListener () {
			public void actionPerformed(ActionEvent e) {

			}
		});
		//add action listener for button save
		saveButton.addActionListener (new ActionListener () {
			public void actionPerformed(ActionEvent e) {

			}
		});
		//add action listner for button close
		closeButton.addActionListener (new ActionListener () {
					public void actionPerformed(ActionEvent e) {

						System.exit(0);
					}
				});
		
	}
	//repair file
	
@SuppressWarnings("resource")
private static void repairData(String fileName) {
		
		//Read from File
		
		String output ="first_name,last_name,company_name,address,city,county,state,zip,phone1,phone2,email,web,zip\n";
		try{
			
			BufferedReader br = null;
			String line;
			br = new BufferedReader(new FileReader(fileName));

			while ((line = br.readLine()) != null) {
				String[] split = line.split(",");
				String phone1 ="";
				String phone2="";
				String email="";
				String web ="";
				String state="";
				String zip="";
				
				
				for(int i=0;i<split.length;i++){
					phoneMatcher = phonePattern.matcher(split[i]);
					
					if(phoneMatcher.matches()){
						
						if(phone1.equals("")){
							phone1 = split[i];
							split[i] = "";
						}
						else
							phone2 = split[i];{
								split[i] = "";
							}
					}
					
					emailMatcher = emailPattern.matcher(split[i]);
					
					if(emailMatcher.matches()){
						email = split[i];
						split[i] = "";
					}
					urlMatcher = webPattern.matcher(split[i]);
					
					if(urlMatcher.matches()){
						web = split[i];
						split[i] = "";
					}
					
					if(split[i].length()==2){
						state=split[i];
						split[i] = "";
						
					}
					
					if(checkInteger(split[i])){
						zip=split[i];
						split[i] = "";
					}
					
				}
				String otherInfo ="";
				for(int i=0;i<split.length;i++){
					if(!split[i].equals("")){
						otherInfo = otherInfo + split[i] + ",";
					}
				}
				
				if(!state.equals(""))
					output =  output + otherInfo + state + "," + zip + "," + phone1 + "," +  phone2 + "," + email + "," + web + "\n";
				
			}
			JOptionPane.showMessageDialog(null, "Data restructured");
			
		}catch(Exception e){
			
		}
		
		}
	


	
	private static boolean checkInteger(String string) {
		try{
			
			Integer.parseInt(string);
			return true;
			
		} catch(Exception e){
			
			return false;

		}
	}
	private static void writeFile(String output) {	
		
		try{
			File file =new File("output.txt");
			FileWriter fileWritter = new FileWriter(file.getName(),true);
			BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
			bufferWritter.write(output);

		
			bufferWritter.close();
		}catch(Exception e){

		}
		
		showData1();
	}
	
	private static void showData1() {
		// TODO Auto-generated method stub
		String display= "";
		for (String[] save : readData1) {
			for(String x: save) {
				display+="";
			}
		}
		outputTextArea.setText(display);
		
	}

	//begin initComponent
	public void initComponent() {
		
		//Instantiate Buttons
		repairButton = new JButton("Repair");
		sortButton = new JButton("Sort");
		saveButton = new JButton("Save");
		closeButton = new JButton("Close");
		
		
		
		//Instantiate textareas
		outputTextArea = new JTextArea(5,30);
		
		
	}//end initComponent
	
	//begin doTheLayout
	public void doTheLayout() {
		
		try {

			GridBagLayout gbl = new GridBagLayout();
			setLayout(gbl);

			gbc.insets = new Insets(15,15,15,15);

			gbc.gridx = 0;
			gbc.gridy = 0;
			gbc.anchor = GridBagConstraints.EAST;
			add(repairButton, gbc);
			
			gbc.gridx = 1;
			gbc.gridy =0;
			gbc.anchor = GridBagConstraints.EAST;
			add(sortButton, gbc);
			
			gbc.gridx = 2;
			gbc.gridy = 0;
			gbc.anchor = GridBagConstraints.EAST;
			add(saveButton, gbc);
			
			gbc.gridx = 3;
			gbc.gridy = 0;
			gbc.anchor = GridBagConstraints.EAST;
			add(closeButton, gbc);
			
			gbc.weightx = 1;
			gbc.fill = GridBagConstraints.HORIZONTAL;
			gbc.anchor = GridBagConstraints.CENTER;
			gbc.gridwidth = 5;
			gbc.gridx=0;
			gbc.gridy=6;
			gbc.anchor=GridBagConstraints.NORTH;
			add(outputTextArea,gbc);
			
		
			 
			
		}catch (Exception e){}
		
	}//end doTheLayout
	

	
	//begin main
	public static void main(String[] args) {

		
		String fileName = RegExPractice.chooseFile();
		
		//Instantiate a JFrame
		f = new JFrame("Contact Program GUI");
		Container contentPane = f.getContentPane();


		//call Constructor ClutteredData
		contentPane.add(new ClutteredData(fileName));
		f.pack();
		
		//Set Position to the Center of the Screen
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		
		
		// make frame visible
		f.setVisible(true);
		
		
		
	}//end main

	
}
