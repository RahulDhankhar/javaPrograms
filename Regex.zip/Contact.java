
public class Contact {
	private String first_name, last_name, company_name,address,city,county,state,phone1,phone2,email,web;
	private int zip;

	// constructor Contact
	public Contact(String first_name,String last_name,String company_name,String address,String city,String county,String state,String phone1,String phone2,String email,String web,
	int zip) {
		this.first_name = first_name;
		this.last_name = last_name;
		this.company_name = company_name;
		this.address =address;
		this.city = city;
		this.county =county;
		this.state = state;
		this.phone1 =phone1;
		this.phone2 = phone2;
		this.email =email;
		this.web = web;
		this.zip =zip;
	}
	//getter and setter methods
	//get first_name
	public String getFirst_name () {
		return first_name;
	}
	//set first_name
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	//get last_name
	public String getLast_name() {
		return last_name;
	}
	//set last_name
	public void setlast_name(String last_name) {
		this.last_name = last_name;
	}
	//get company_name
	public String getCompany_name() {
		return company_name;
	}
	//set company_name
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	//get address
	public String getAddress() {
		return address;
	}
	//set address
	public void setAddress(String address) {
		this.address = address;
	}
	//get city
	public String getCity() {
		return city;
	}
	//set city
	public void setCity(String city) {
		this.city = city;
	}
	//get county
	public String getCounty() {
		return county;
	}
	//set county
	public void setCounty(String county) {
		this.county = county;
	}
	//get state
	public String getState() {
		return state;
	}
	//set state
	public void setState(String state) {
		this.state = state;
	}
	//get phone1
	public String getPhone1() {
		return phone1;
	}
	//set phone1
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	//get phone2
	public String getPhone2() {
		return phone2;
	}
	//set phone2
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	//get email
	public String getEmail() {
		return email;
	}
	//set email
	public void setEmail(String email) {
		this.email = email;
	} 
	//get web
	public String getWeb() {
		return web;
	}
	//set web
	public void setWeb(String web) {
		this.web = web;
	}
	//get zip
	public int getZip() {
		return zip;
	}
	//set zip
	public void setZip(int zip) {
		this.zip = zip;
	}
	
	
@Override
	
	public String toString() {
	return "Name:" + this.first_name + " "+ this.last_name
            + "Address:" + this.address + " " + this.city;
	}
	
}
