import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class RegExPractice {
	
	
	public static final String readData1 = null;

	public static String chooseFile() {
	 JFileChooser chooser = new JFileChooser(System.getProperty("input"));
		
		//chooser.setCurrentDirectory(new java.io.File("."));
		if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			String fileName = String.valueOf(chooser.getSelectedFile());
			File file =new File("input.txt");
			/**
			FileWriter fileWritter = new FileWriter(file.getName(),true);
			Reader myReader = new BufferedReader(new FileReader("Input.txt"));*/
			return file.getAbsolutePath();
			
			
	

		
		//else {}
	}
		return null;
}
	
	public static ArrayList<String []> readData1(String fileName) {
		ArrayList<String[]> display = new ArrayList<>();
		try {
			Scanner scn = new Scanner (new File(fileName));
			if (scn.hasNextLine()) {
				scn.nextLine();
			}
			
			//int n = 0;
			while (scn.hasNextLine()) {
			
			display.add(scn.nextInt(), null);
				//n++;
				
			}scn.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
			
}
			
  



