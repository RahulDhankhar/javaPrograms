
//add the class template

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;


//begin class PetClent
class PetClent extends JPanel {
	
	GridBagConstraints gbc = new GridBagConstraints();

	private static String hostname;
	private static int port = 8000;
	private Message msg;
	
	static private final int INSERT_OP =0;
	static private final int VIEW_OP =1;
	static private final int UPDATE_OP =2;
	static private final int DELETE_OP =3;

// declare UI component objects
	
	//declare and instantiate labels
	private JLabel tagLabel = new JLabel("Tag");
	private JLabel ownerSSNLabel= new JLabel("Owner SSN");
	
	//private JLabel opTypeLabel;
	private JLabel petNameLabel = new JLabel("Pet Name");
	private JLabel firstNameLabel= new JLabel("First name");
	private JLabel lastNameLabel= new JLabel("Last Name");
	private JLabel speciesLabel= new JLabel("Species");
	
	//declare and instantiate combo box
	private JComboBox<String> speciesComboBox = new JComboBox<String>();
	
	// declare and instantiate textfield
	private JTextField tagTextField = new JTextField(5);
	private JTextField ownerSSNTextField = new JTextField(10);
	
	//private JTextField opTypeTextField = new JTextField(5);
	private JTextField petNameTextField = new JTextField(10);
	private JTextField firstNameTextField = new JTextField(10);
	private JTextField lastNameTextField = new JTextField(10);
	

	// declare and instantiate buttons 
	private JButton insertButton = new JButton("Insert");
	private JButton viewButton = new JButton("View");
	private JButton updateButton = new JButton("Update");
	private JButton deleteButton = new JButton("Delete");
	private JButton clearButton = new JButton("Clear");
	private JButton closeButton = new JButton("Close");
	
	static JFrame f;
	
//begin constructor petClient	
public PetClent(String hostname, int port) throws IOException {
	
	this.port = port;
	this.hostname = hostname;
	
	// Create a connection with the PetServer server on port number 8000
	connectServer(hostname, port);
	
	
	// call these two methods to create user GUI
	doTheLayout();
	
	speciesComboBox.addItem("Dog");
	speciesComboBox.addItem("Cat");
	speciesComboBox.addItem("Rabbit");
	speciesComboBox.addItem("Hamster");
	
	// add action listener to insert button
	insertButton.addActionListener(new ActionListener() {

		public void actionPerformed(ActionEvent e) {
			boolean validateForInsert = validateForInsert();
			if(validateForInsert()) {
			String tag = tagTextField.getText().trim();
			String petName = petNameTextField.getText().trim();
			String ownerSSN = ownerSSNTextField.getText().trim();
			String firstName = firstNameTextField.getText().trim();
			String lastName = lastNameTextField.getText().trim();
			String species = speciesComboBox.getSelectedItem().toString();
			
			sendMsg(Integer.parseInt(tag), petName, Integer.parseInt(ownerSSN),firstName,lastName,species,insertButton );
			
			
		} 
		}
		private void sendMsg(int parseInt, String petName, int parseInt2, String firstName, String lastName,
				String species, JButton insertButton) {
			// TODO Auto-generated method stub
			
		}

		private boolean validateForInsert() {
			boolean validate = true;
			
			String tag = tagTextField.getText().trim();
			String petName = petNameTextField.getText().trim();
			String ownerSSN = ownerSSNTextField.getText().trim();
			String firstName = firstNameTextField.getText().trim();
			String lastName = lastNameTextField.getText().trim();
			String species = speciesComboBox.getSelectedItem().toString();
			
			
			if(!checkInteger(tag,"Tag")) {
				validate = false;
			} else if(tag.equals("")){
				JOptionPane.showMessageDialog(null,"Pet Name is not provided");
				validate = false;
			}else if(species.equals("")) {
				JOptionPane.showMessageDialog(null,"Pet species is not selected");
				validate = false;
			}else if(firstName.equals("")) {
				JOptionPane.showMessageDialog(null,"First Name is not provided");
				validate = false;
			}else if(lastName.equals("")) {
				JOptionPane.showMessageDialog(null,"Last Name is not provided");
				validate = false;
			}else if(petName.equals("")) {
				JOptionPane.showMessageDialog(null,"Pet Name is not provided");
				validate = false;
			}else if(ownerSSN.equals("")) {
				JOptionPane.showMessageDialog(null,"SSN is not provided");
				validate = false;
			}
			
			return validate;
		}

		private boolean checkInteger(String tag, String string) {
			// TODO Auto-generated method stub
			return false;
		}
		
	});
	
	
	// add action listener to view button
	
	viewButton.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			boolean validateForView = validateForView();
			
			if(validateForView) {
				try {
					String tag = tagTextField.getText().trim();
				}catch (Exception ex) {System.out.println(e);}
			}
			
		}

		private boolean validateForView() {
			boolean validate = true;
			String tag = tagTextField.getText().trim();
			if(!checkInteger(tag,"Tag")) {
				validate = false;
			}
			return validate;
		}

		private boolean checkInteger(String tag, String string) {
			boolean validate= true;
			
			int val = Integer.parseInt(tag);
			try{
			if (val<=0) {
				JOptionPane.showMessageDialog(null, string +" must be greater than 0" );
				validate = false;
			}
			}catch(Exception e) {
				JOptionPane.showMessageDialog(null, "Enter again for" +string);
			}
			
			return validate;
		}});
	// add action listener to update button
	updateButton.addActionListener(new ActionListener() {
	
		@Override
		public void actionPerformed(ActionEvent e) {
			boolean validateForUpdateButton = validateForUpdateButton();
			if(validateForUpdateButton) {
			String tag = tagTextField.getText().trim();
			String petName = petNameTextField.getText().trim();
			String ownerSSN = ownerSSNTextField.getText().trim();
			String firstName = firstNameTextField.getText().trim();
			String lastName = lastNameTextField.getText().trim();
			String species = speciesComboBox.getSelectedItem().toString();
			
			sendMsg(Integer.parseInt(tag), petName, Integer.parseInt(ownerSSN),firstName,lastName,species,insertButton );
			
			
		}

		}

		private void sendMsg(int parseInt, String petName, int parseInt2, String firstName, String lastName,
				String species, JButton insertButton) {
			// TODO Auto-generated method stub
			
		}

		private boolean validateForUpdateButton() {
			boolean validate =true;
			String tag = tagTextField.getText().trim();
			String petName = petNameTextField.getText().trim();
			String ownerSSN = ownerSSNTextField.getText().trim();
			String firstName = firstNameTextField.getText().trim();
			String lastName = lastNameTextField.getText().trim();
			String species = speciesComboBox.getSelectedItem().toString();
			
			if(!checkInteger(tag,"Tag")) {
				validate = false;
			} else if(tag.equals("")){
				JOptionPane.showMessageDialog(null,"Pet Name is not provided");
				validate = false;
			}else if(species.equals("")) {
				JOptionPane.showMessageDialog(null,"Pet species is not selected");
				validate = false;
			}else if(firstName.equals("")) {
				JOptionPane.showMessageDialog(null,"First Name is not provided");
				validate = false;
			}else if(lastName.equals("")) {
				JOptionPane.showMessageDialog(null,"Last Name is not provided");
				validate = false;
			}else if(petName.equals("")) {
				JOptionPane.showMessageDialog(null,"Pet Name is not provided");
				validate = false;
			}else if(ownerSSN.equals("")) {
				JOptionPane.showMessageDialog(null,"SSN is not provided");
				validate = false;
			}
			
			return validate;
		}

		private boolean checkInteger(String tag, String string) {
			boolean validate= true;
			
			int val = Integer.parseInt(tag);
			try{
			if (val<=0) {
				JOptionPane.showMessageDialog(null, string +" must be greater than 0" );
				validate = false;
			}
			}catch(Exception e) {
				JOptionPane.showMessageDialog(null, "Enter again for" +string);
			}
			
			return validate;
		}});
	// add action listener to delete button
	deleteButton.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			boolean validateForDelete = validateForDelete();
			
			
			if(validateForDelete) {
				try {
					String tag = tagTextField.getText().trim();
					int option = JOptionPane.showConfirmDialog(null,"Would you like to delete ?");
					
					if(option == JOptionPane.YES_OPTION) {
						tagTextField.setText("");
					}
				}catch(Exception ex) {
					System.out.println(e);
				}
			}
		}

		private boolean validateForDelete() {
			boolean validate = true;
			String tag = tagTextField.getText().trim();
			if(!checkInteger(tag,"Tag")) {
				validate = false;
			}
			return validate;
		}

		private boolean checkInteger(String tag, String string) {
			// TODO Auto-generated method stub
			return false;
		}
		
	});
	// add action listener to clear button
	clearButton.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			String tag = tagTextField.getText().trim();
			String petName = petNameTextField.getText().trim();
			String ownerSSN = ownerSSNTextField.getText().trim();
			String firstName = firstNameTextField.getText().trim();
			String lastName = lastNameTextField.getText().trim();
			String species = speciesComboBox.getSelectedItem().toString();
			
			try {
				
				int option = JOptionPane.showConfirmDialog(null,"Would you like to clear the fields ?");
				
				if(option == JOptionPane.YES_OPTION) {
					tagTextField.setText("");
					petNameTextField.setText("");
					ownerSSNTextField.setText("");
					firstNameTextField.setText("");
					lastNameTextField.setText("");
					speciesComboBox.setSelectedItem("");
				}
			}catch(Exception ex) {
				System.out.println(e);
			}
			
		}
		
	});
	
	
	// add action listener to close button
	closeButton.addActionListener (new ActionListener () {
		public void actionPerformed(ActionEvent e) {

			System.exit(0);
		}
	});
	
	
}// end constructor PetClent




private void connectServer(String hostAddress,int  connectingPort) throws IOException{
	try {
		conn("localhost", port)
		;}catch(Exception e){System.out.println(e);}
}

private void conn(String string, int port1) {
	// TODO Auto-generated method stub
	
}

//begin doTheLayout
private void doTheLayout(){
	// Arrange the UI components into GUI window
	try {
		GridBagLayout gbl = new GridBagLayout();
		setLayout(gbl);

		gbc.insets = new Insets(10,10,10,10);
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.EAST;
		add(tagLabel, gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.EAST;
		add(tagTextField, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.anchor = GridBagConstraints.EAST;
		add(petNameLabel, gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.anchor = GridBagConstraints.EAST;
		add(petNameTextField, gbc);
		
		gbc.gridx = 2;
		gbc.gridy = 1;
		gbc.anchor = GridBagConstraints.EAST;
		add(speciesLabel, gbc);
		
		gbc.gridx = 3;
		gbc.gridy = 1;
		gbc.anchor = GridBagConstraints.EAST;
		add(speciesComboBox, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.anchor = GridBagConstraints.EAST;
		add(ownerSSNLabel, gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.anchor = GridBagConstraints.EAST;
		add(ownerSSNTextField, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.anchor = GridBagConstraints.EAST;
		add(firstNameLabel, gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.anchor = GridBagConstraints.EAST;
		add(firstNameTextField, gbc);
		
		gbc.gridx = 2;
		gbc.gridy = 3;
		gbc.anchor = GridBagConstraints.EAST;
		add(lastNameLabel, gbc);
		
		gbc.gridx = 3;
		gbc.gridy = 3;
		gbc.anchor = GridBagConstraints.EAST;
		add(lastNameTextField, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.anchor = GridBagConstraints.EAST;
		add(insertButton, gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.anchor = GridBagConstraints.EAST;
		add(viewButton, gbc);
		
		gbc.gridx = 2;
		gbc.gridy = 4;
		gbc.anchor = GridBagConstraints.EAST;
		add(updateButton, gbc);
		
		gbc.gridx = 3;
		gbc.gridy = 4;
		gbc.anchor = GridBagConstraints.EAST;
		add(deleteButton, gbc);
		
		gbc.gridx = 4;
		gbc.gridy = 4;
		gbc.anchor = GridBagConstraints.EAST;
		add(clearButton, gbc);
		
		gbc.gridx = 5;
		gbc.gridy = 4;
		gbc.anchor = GridBagConstraints.EAST;
		add(closeButton, gbc);	
		
	}catch(Exception e) {}
}// end doTheLayout	
	

  
  /**Main method
 * @throws IOException */
  public static void main(String[] args) throws IOException {
	  
	  // create the user GUI
	  
	//Instantiate a JFrame as  as Pet store 
	  f = new JFrame("Pet Store");
	  Container contentPane = f.getContentPane();
	//call Constructor UserGUI
		contentPane.add(new PetClent(hostname, port));
		f.pack();
		
		//Set Position to the Center of the Screen
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		
		// set resizable false
		f.setResizable(false);
		
		// make frame visible
		f.setVisible(true);

  }


}// end class petClent