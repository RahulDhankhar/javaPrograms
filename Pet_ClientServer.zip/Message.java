
//add the class template

import java.io.Serializable;
import java.sql.Date;


public class Message implements Serializable {
	
	private int tag, ownerSSN, opType;
	private String petName, species, firstName, lastName;
	
	//constructor message
	public Message(int tag, int ownerSSN, int opType, String petName, String species, String firstName,
			String lastName) {
		this.tag = tag;
		this.ownerSSN = ownerSSN;
		this.opType = opType;
		this.petName = petName;
		this.species = species;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	// provide the getter and setter methods
	//get tag
	public int getTag() {
		return tag;
	}
	//set tag
	public void setTag(int tag) {
		this.tag = tag;
	}
	//get owner SSN
	public int getOwnerSSN() {
		return ownerSSN;
	}
	//set owner SSN
	public void setOwnerSSN(int ownerSSN) {
		this.ownerSSN = ownerSSN;
	}
	//get operation Type
	public int getOpType() {
		return opType;
	}
	//set operation Type
	public void setOpType(int opType) {
		this.opType = opType;
	}
	//get pet name
	public String getPetName() {
		return petName;
	}
	//set pet name
	public void setPetName(String petName) {
		this.petName = petName;
	}
	//get pet species 
	public String getSpecies() {
		return species;
	}
	//set pet species 
	public void setSpecies(String species) {
		this.species= species;
	}
	//get firstName
	public String getFirstName() {
		return firstName;
	}
	//set first name
	public void setFirstName(String firstName) {
		this.firstName= firstName;;
	}
	//get last name
	public String getLastName() {
		return lastName;
	}
	//set last name
	public void setLastname(String lastName) {
		this.lastName = lastName;
	}
	
	@Override
	
	public String toString() {
		return "Pet Name :"+petName + "\t" +"Owner First name"+firstName+"\t"+"Pet tag"+tag;
	}
	
		
}
