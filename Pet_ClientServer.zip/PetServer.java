
// add the class template 

import java.awt.*;
import java.awt.event.*;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.applet.*;
import javax.swing.*;

import java.sql.*;
import javax.swing.border.*;

public class PetServer {
	
	
	
	
   Socket		conn;
   ServerSocket 		serverSocket;
   ObjectInputStream serverInputStream;
   ObjectOutputStream serverOutputStream; 
	
  Message message;
  Connection connection = null;
  private Statement stmt;
  private int port;
  private Message msg;
  //static private final int INSERT_OP =0;
  //static private final int VIEW_OP =1;
  //static private final int UPDATE_OP =2;
  //static private final int DELETE_OP =3;  
  
  
  
  public PetServer (int port) throws ClassNotFoundException, IOException, SQLException{
	  
	  this.port = port;
	  initializeDB();

  }
//begin initialize db
private void initializeDB () {
   /**
	try {
      // create the server
	  ServerSocket serverSocket = new ServerSocket(8000);
      System.out.println("Server started ");
      Socket client = serverSocket.accept();
      
      try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      System.out.println("Driver loaded");
      
   
	  
	  // Connect to your database using your credentials
		// Establish a connection
		try {
			Connection connection = DriverManager.getConnection
			("jdbc:mysql://hostname/yourdatabase", "rahul1u", "c618c!03114");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  System.out.println("Server started ");
    }catch(IOException e){
    	e.printStackTrace();
    }
      // Create a statement object
	  
	  // loops for ever waiting for the client connection requests
	  	     // create a thread for each client connection request using Runnable class HandleAClient */
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		connection  = DriverManager.getConnection("jdbc:mysql://hostname/rahul1udb", "rahul1u", "c618c!03114");
		

	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      System.out.println("Driver loaded");
      
     
  }//end initialize db




/**
private void initializeComponents()
{
txtDisplayResults = new JTextArea(20, 40);
btnCloseButton = new JButton("Close");
txtDisplayResults.setEditable(false);
}


private void initializeLayout() {

JPanel displayPanel = new JPanel();
JPanel buttonPanel = new JPanel();

displayPanel.setLayout( new BorderLayout());
displayPanel.add( new JLabel( "Client Request:" ), BorderLayout.NORTH );
displayPanel.add(txtDisplayResults, BorderLayout.CENTER);

buttonPanel.setLayout( new FlowLayout());
buttonPanel.add(btnCloseButton);

JScrollPane scroll = new JScrollPane ( txtDisplayResults );
scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
displayPanel.add(scroll);

setLayout(new BorderLayout());
add(displayPanel, BorderLayout.CENTER);
add(buttonPanel, BorderLayout.SOUTH);

}


void close_actionPerformed(ActionEvent e) throws IOException{

System.exit(0);
  
}*/



 

  /**View record by ID*/
  private static void view() {
	 
   // Build a SQL SELECT statement
	  try {
		  String query = "select * from owner";
		  
	  } catch (Exception e) {
		 System.out.println(e);
	  }
    
  }

  
  /**Insert a new record*/
  private void insert() {
    // Build a SQL INSERT statement
	  try {
		  String query = "Insert into owner(ssn, firstName, lastName)";
	  } catch (Exception e) {
		 System.out.println(e);
	  }
    
  }

   

  /**Update a record*/
  private void update() {
  // Build a SQL UPDATE statement
	  try {
		  String query = "UPDATE owner SET firstName = eden, lstName = hazard, WHERE ssn = 1232802;";
	  } catch (Exception e) {
		 System.out.println(e);
	  }
  }

  /**Clear text fields*/
  private void delete() {
	// Build a SQL DELETE statement
  }

    // inner Runnable class handle a client connection
	class HandleAClient implements Runnable {
	    private Socket socket; // A connected socket

	    /** Construct a thread */
	    public HandleAClient(Socket socket) {
	      this.socket = socket;
	    }

	    /** Run a thread */
	    public void run() {
	    	
	    	// write the code to call a proper method to process the client request
	    }
	   }// end of class Runnable 
  
  public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException {
	  //view();
	  try{
		  PetServer server = new PetServer(8000);
		  server.initializeDB();
	  }catch(Exception e) {}
    
    
  }
}
