import javax.swing.JOptionPane;

// start class runDice 
public class runDice {
	static int rollNum = 0;
	static boolean six;
	static boolean five;
	static boolean four;
//array of five different die objects
	static die[] arrDice = new die[5];
//specify min and max of the dice
	static int min =1;
	static int max = 6;
//check for current state
	static String  currState="";
//display score
	static int finalScore =0;

//establish what attained
	//displayState begin
	public static void displayState() {
		
		//all not attained
		if (six == false && five == false && four == false) {
			currState ="Overall results\n Ship, Captain and Crew not Attained";
			JOptionPane.showMessageDialog(null,currState);
		}
		//only ship attained
		else if (six == true && five == false && four == false) {
			currState ="Overall results\n Ship- attained,\n Captain and Crew not Attained";
			JOptionPane.showMessageDialog(null,currState);
		}
		//ship and captain attained
		else if (six == true && five == true && four == false) {
			currState ="Overall results\n Ship and Captain - attained, \n Crew not Attained";
			JOptionPane.showMessageDialog(null,currState);
		}
		//all attained
		else if (six == true && five == true && four == true) {
			currState ="Overall results\n Ship, Captain and Crew Attained";
			JOptionPane.showMessageDialog(null,currState);
		}
	}//end displayState
	
//associate numbers in die with boolean six, five and four
	//begin linkDie
	public static void linkDie() {
		for (int i=0;i<arrDice.length;i++) {
			
			if (arrDice[i].getNumber()==6) {
				six = true;
				arrDice[i].setKeep(true);
			}
			
			if (arrDice[i].getNumber()==5) {
				if(six ==true) {
				five = true;
				arrDice[i].setKeep(true);
			}
			}
			if (arrDice[i].getNumber()==4) {
				if (six == true && five == true) {
				four = true;
				arrDice[i].setKeep(true);
			}
			}
		}
	}//end link die
	

//Initialize the 5 dice objects
	//begin initDie
	public static void initDie() {
		for(int i=0;i<5;i++) {
//create place to store die class object			
			arrDice[i] = new die();
		}
	}//end initDie
	
	
//called for each rolled dice
	//begin roll
	public static void roll() {
	while (rollNum<3) {
		initDie();
		rollNum = rollNum +1;
		
//check for Ship, Captain and Crew are attained or not
		
	//condition 1- where Ship, Captain and Crew are not attained
		//begin if statement
	if((six == false) && (five == false) && (four == false)) {
		
		//display result
		String result="";
		
		for (int i =0;i<5;i++) { 
			
		//generate random number
		int random = (int) (Math.random() * (max - min + 1) + min);
		//set the number to die object in array
		arrDice[i].setNumber(random);
		// result stores the numbers generated with a space
		result = result + arrDice[i].getNumber() + " ";
		}
		//display result
		JOptionPane.showMessageDialog(null, "Here are the results of our dice roll "+ rollNum +"\n"+result);
		
		// sort the numbers using sort array
		
		int arrSort[] = new int[5];
		
		for(int i=0; i<arrDice.length;i++) { 
			
			arrSort[i] =arrDice[i].getNumber();		
			}
		
		//return sorted array
		arrSort = getArrSort (arrSort);
		
		//Set sorted array back to die objects
		for(int i=0; i<arrSort.length;i++) {
			
			arrDice[i].setNumber(arrSort[i]);		
			} 
		
		linkDie();
		displayState();
	}//end if statement
	
	//Condition 2- where Captain and crew are not attained
	//begin else if statement
	else if ((six == true)&&(five==false)&&(four==false)) {

		//display result
		String result="";
		
		for (int i =0;i<4;i++) { 
			
		//generate random number
		int random = (int) (Math.random() * (max - min + 1) + min);
		//set the number to die object in array
		arrDice[i].setNumber(random);
		// result stores the numbers generated with a space
		result = result + arrDice[i].getNumber() + " ";
		}
		//display result
		JOptionPane.showMessageDialog(null, "Here are the results of our dice roll "+ rollNum +"\n"+result);
				
		// sort the numbers using sort array
		int arrSort[] = new int[4];
		for(int i=0; i<arrSort.length;i++) {
		arrSort[i] =arrDice[i].getNumber();		
		}
		//return sorted array
		arrSort = getArrSort (arrSort);
				
		//Set sorted array back to die objects
		for(int i=0; i<arrSort.length;i++) {
		arrDice[i].setNumber(arrSort[i]);		
				}
		
		linkDie();
		displayState();
	}//end else if statement
	
	
	//Condition 3- where crew is not attained
		//begin else if statement
	else if ((six == true)&&(five==true)&&(four==false)) {

		//display result
		String result="";
		
		for (int i =0;i<3;i++) { 
			
		//generate random number
		int random = (int) (Math.random() * (max - min + 1) + min);
		//set the number to die object in array
		arrDice[i].setNumber(random);
		// result stores the numbers generated with a space
		result = result + arrDice[i].getNumber() + " ";
		}
		//display result
		JOptionPane.showMessageDialog(null, "Here are the results of our dice roll "+ rollNum +"\n"+result);
				
		// sort the numbers suing sort array
		int arrSort[] = new int[3];
		for(int i=0; i<arrSort.length;i++) {
		arrSort[i] =arrDice[i].getNumber();		
		}
				
		//return sorted array
		arrSort = getArrSort (arrSort);
				
		//Set sorted array back to die objects
		for(int i=0; i<arrSort.length;i++) {
		arrDice[i].setNumber(arrSort[i]);		
		           }
		
		linkDie();
		displayState();
	}//end else if statement
	
	
	
	//Condition 4- where Ship, Captain and Crew are attained
			//begin else if statement
		else if ((six == true)&&(five==true)&&(four==true)) {

			//display result
			String result="";
			
			for (int i =0;i<2;i++) { 
				
			//generate random number
			int random = (int) (Math.random() * (max - min + 1) + min);
			//set the number to die object in array
			arrDice[i].setNumber(random);
			// result stores the numbers generated with a space
			result = result + arrDice[i].getNumber() + " ";
			}
			//display result
			JOptionPane.showMessageDialog(null, "Here are the results of our dice roll "+ rollNum +"\n"+result);
				
					
			displayState();
		}//end else if statement
	
	if((six==true) && (five==true) && (four == true)) {
		// check for remaining dice rolls
		int remainedRoll = (3-rollNum);
		
		//display remained rolls
		JOptionPane.showMessageDialog(null, "After attaining Ship, captain and crew, number of rolls remained is "
		+remainedRoll);
		
		//check with user if wants to continue or not
		if(remainedRoll>0) {
			int nextStep = JOptionPane.showConfirmDialog(null, "Would you like to continue?");
			//user continues
			if(nextStep ==JOptionPane.YES_OPTION) {
			}
			else {
				calculateScore();
				finalScore();
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "All chances for roll dice is over.");
			calculateScore();
			finalScore();
			}
		}
			else if(rollNum ==3) {
				
			JOptionPane.showMessageDialog(null, "All chances for roll dice is over. Your score is 0");
			System.exit(0);
			}	
	
	
	}//end while	
	}//end roll
	
	
	
private static int[] getArrSort(int[] arrSort) {
	
		for (int i=0; i< arrSort.length;i++){
			
			for(int j=0; j <arrSort.length;j++) {
				
				if ((j+1)<arrSort.length)	{
					
					if (arrSort[j]<arrSort[j+1]) {
						
					int temp = arrSort[j];
					arrSort[j] = arrSort[j+1];
					arrSort[j+1]=temp;
				}
				}
			}
		}
		return arrSort;
	}

public static void calculateScore() {
	//set kept die to zero
	int keptDie =0;
	
	for(int i=0; i<arrDice.length;i++) {
		
		if(arrDice[i].getNumber() != 0)
			arrDice[i].setKeep(true);
	} 
	
	for(int i =0; i<arrDice.length;i++) {
		finalScore = finalScore + arrDice[i].getNumber();
		if (arrDice[i].getKeep()==true) {
			keptDie = keptDie +1;
		}
	}
	if (keptDie==5)
		//subtract 6+5+4
		finalScore = finalScore-15;
	
	else if (keptDie==4) 
		//subtract 5+4
		finalScore = finalScore-9;
	else if (keptDie==3) 
		//subtract 4
		finalScore=finalScore-4;
	
}	
public static void finalScore() {
	JOptionPane.showMessageDialog(null,"The final score is " +"\n" +finalScore);
	System.exit(0);
}
	
	
//main starts
public static void main (String[] args) {
initDie();
roll();
}//main ends

}//class runDice ends
