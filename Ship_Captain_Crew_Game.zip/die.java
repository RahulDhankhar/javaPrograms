
// start class die
public class die {
	
public int number;
public boolean keep;

// constructor
die(){
	number =0;
	keep = false;
}
//return keep
public boolean getKeep() {
	return keep;
}
//set keep
public void setKeep(boolean keep) {
	this.keep = keep;
}
//return number
public int getNumber() {
	return number;
}
// set number
public void setNumber(int number) {
	this.number = number;
}
}
